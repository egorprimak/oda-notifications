(class extends odaAction {

    static get properties() {
        return {
            label: 'module-info',
            allowAccess: 'A',
            allowUse: true,
            allowExport: false,
            allowArrayContext: false,
            icon: 'icons:settings-applications',
        };
    }
}).register();
(class extends odaAction {

    async execute() {
        const {sendMail} = await import('./nodemailer/index.js');
        const object = this.contextItem;
        const cid = object.$class.id;

        const staticObject = (await object.$class.getObject(cid)).Root;
        const auth = {user: staticObject.login, pass: staticObject.password};
        const host = staticObject.host;
        const port = staticObject.port;
        const secure = staticObject.secure;

        const mail = {subject: object.Root.subject, text: object.Root.body};
        const cred = {to: object.Root.to, from: object.Root.from || staticObject.from || ''};

        sendMail(auth, cred, mail, host, port, secure)
            .then((e) => {
                object.Root.info = JSON.stringify(e)
                object.save()
        });
    }
    
}).register();